from django.contrib import admin
from .forms import Profile

# Register your models here.
admin.site.register(Profile)