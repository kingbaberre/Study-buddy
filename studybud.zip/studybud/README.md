just a simple app for quiz and forum
